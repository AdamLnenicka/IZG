var searchData=
[
  ['cameraanglex',['cameraAngleX',['../mouseCamera_8c.html#a07175deab1c8d4fe3e322425c5152e3b',1,'mouseCamera.c']]],
  ['cameraangley',['cameraAngleY',['../mouseCamera_8c.html#a7083b864216ba85846a35f357692b39f',1,'mouseCamera.c']]],
  ['cameradistance',['cameraDistance',['../mouseCamera_8c.html#a136b2fc24027dfa0965e9b01ab5790aa',1,'mouseCamera.c']]],
  ['camerafar',['cameraFar',['../mouseCamera_8c.html#a3a22d6e2b695df901da8208ac4d90ade',1,'mouseCamera.c']]],
  ['camerafovy',['cameraFovy',['../mouseCamera_8c.html#af135d3eacbf5e0b637a6264026804882',1,'mouseCamera.c']]],
  ['cameramaxdistance',['cameraMaxDistance',['../mouseCamera_8c.html#a019c3cd69d1d3abdb1085d7111103df2',1,'mouseCamera.c']]],
  ['cameramindistance',['cameraMinDistance',['../mouseCamera_8c.html#a01c3865724803dbc7c167d0bafb2dfc1',1,'mouseCamera.c']]],
  ['cameranear',['cameraNear',['../mouseCamera_8c.html#af67fe3c4ab506b27455d3e5e2a1c1dde',1,'mouseCamera.c']]],
  ['cameraposition',['cameraPosition',['../globals_8c.html#a2ae2553412ead34e3a4e23019d4f052e',1,'cameraPosition():&#160;globals.c'],['../globals_8h.html#a2ae2553412ead34e3a4e23019d4f052e',1,'cameraPosition():&#160;globals.c']]],
  ['camerasensitivity',['cameraSensitivity',['../mouseCamera_8c.html#a64978db94ae584bb869720f12f1c605e',1,'mouseCamera.c']]],
  ['camerazoomspeed',['cameraZoomSpeed',['../mouseCamera_8c.html#a9ef2ba364254daa73ccc3b9c226d87d6',1,'mouseCamera.c']]],
  ['color',['color',['../structGPUFragmentShaderOutput.html#a209315abb3483aac58aad3954e8ecad1',1,'GPUFragmentShaderOutput']]],
  ['column',['column',['../structMat4.html#a89c6922a5ca3584062e9841090709592',1,'Mat4']]],
  ['coords',['coords',['../structGPUFragmentShaderInput.html#a6164fa8964152f4a4feb231926efa368',1,'GPUFragmentShaderInput::coords()'],['../structGPUTriangle.html#a1cd3fe2c1979f844528481ee336d4e09',1,'GPUTriangle::coords()']]]
];
