var searchData=
[
  ['leftmousebuttondown',['leftMouseButtonDown',['../mouseCamera_8c.html#a502f2f96ed635993c6d0350428210255',1,'mouseCamera.c']]],
  ['lightposition',['lightPosition',['../structPhongVariables.html#aab37c6c27bf6eac7d326a34afb74c90c',1,'PhongVariables']]]
];
