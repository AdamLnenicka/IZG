var searchData=
[
  ['distanceto2dline',['distanceTo2DLine',['../linearAlgebra_8c.html#ad4ecb8c395a729c3bac403a4f430d3cd',1,'distanceTo2DLine(Vec3 const *const line, Vec2 const *const vertex):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#ad4ecb8c395a729c3bac403a4f430d3cd',1,'distanceTo2DLine(Vec3 const *const line, Vec2 const *const vertex):&#160;linearAlgebra.c']]],
  ['dot_5fvec2',['dot_Vec2',['../linearAlgebra_8c.html#a84d6cf8f129f96393c19af1cd4da6475',1,'dot_Vec2(Vec2 const *const left, Vec2 const *const right):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a84d6cf8f129f96393c19af1cd4da6475',1,'dot_Vec2(Vec2 const *const left, Vec2 const *const right):&#160;linearAlgebra.c']]],
  ['dot_5fvec3',['dot_Vec3',['../linearAlgebra_8c.html#a2edd6c868ced671c9680036a35c2a928',1,'dot_Vec3(Vec3 const *const left, Vec3 const *const right):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a2edd6c868ced671c9680036a35c2a928',1,'dot_Vec3(Vec3 const *const left, Vec3 const *const right):&#160;linearAlgebra.c']]],
  ['dot_5fvec4',['dot_Vec4',['../linearAlgebra_8c.html#a41de0162479b762fb9636c4ca2ec67bc',1,'dot_Vec4(Vec4 const *const left, Vec4 const *const right):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a41de0162479b762fb9636c4ca2ec67bc',1,'dot_Vec4(Vec4 const *const left, Vec4 const *const right):&#160;linearAlgebra.c']]]
];
