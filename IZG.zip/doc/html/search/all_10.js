var searchData=
[
  ['todo_20list',['Todo List',['../todo.html',1,'']]],
  ['top',['TOP',['../student__pipeline_8h.html#ae9e1c8a3d097c4fa8df79abc03911ec5a0ad44897a70fba309c24a5b6007de3e3',1,'student_pipeline.h']]],
  ['translate_5fmat4',['translate_Mat4',['../linearAlgebra_8c.html#a4ea2f3b452065b47f0068eb9b4cc4ca9',1,'translate_Mat4(Mat4 *const output, float const tx, float const ty, float const tz):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a4ea2f3b452065b47f0068eb9b4cc4ca9',1,'translate_Mat4(Mat4 *const output, float const tx, float const ty, float const tz):&#160;linearAlgebra.c']]],
  ['transpose_5fmat4',['transpose_Mat4',['../linearAlgebra_8c.html#af2abaae108c4a9bfb7c97e96e0b929be',1,'transpose_Mat4(Mat4 *const output, Mat4 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#af2abaae108c4a9bfb7c97e96e0b929be',1,'transpose_Mat4(Mat4 *const output, Mat4 const *const input):&#160;linearAlgebra.c']]],
  ['triangleexample',['triangleExample',['../triangleExample_8c.html#a235d77635ad30ec86f81d2caabbdc1b5',1,'triangleExample.c']]],
  ['triangleexample_2ec',['triangleExample.c',['../triangleExample_8c.html',1,'']]],
  ['triangleexample_2eh',['triangleExample.h',['../triangleExample_8h.html',1,'']]],
  ['triangleexample_5ffragmentshader',['triangleExample_fragmentShader',['../triangleExample_8c.html#a098ba4902bcb365ea8faaa20be1994f4',1,'triangleExample.c']]],
  ['triangleexample_5fondraw',['triangleExample_onDraw',['../triangleExample_8c.html#adad04513776893b55b58aa0e8a84b8df',1,'triangleExample_onDraw(SDL_Surface *surface):&#160;triangleExample.c'],['../triangleExample_8h.html#adad04513776893b55b58aa0e8a84b8df',1,'triangleExample_onDraw(SDL_Surface *surface):&#160;triangleExample.c']]],
  ['triangleexample_5fonexit',['triangleExample_onExit',['../triangleExample_8c.html#a35b10f59fe16423447777ba6bbba3b66',1,'triangleExample_onExit():&#160;triangleExample.c'],['../triangleExample_8h.html#a35b10f59fe16423447777ba6bbba3b66',1,'triangleExample_onExit():&#160;triangleExample.c']]],
  ['triangleexample_5foninit',['triangleExample_onInit',['../triangleExample_8c.html#a73184b4ab6bb513ad9a9a4c36e92646b',1,'triangleExample_onInit(int32_t width, int32_t height):&#160;triangleExample.c'],['../triangleExample_8h.html#a73184b4ab6bb513ad9a9a4c36e92646b',1,'triangleExample_onInit(int32_t width, int32_t height):&#160;triangleExample.c']]],
  ['triangleexample_5fvertexshader',['triangleExample_vertexShader',['../triangleExample_8c.html#ae87aa91cb96803929e3d70f2ee66794c',1,'triangleExample.c']]],
  ['triangleexamplevariables',['TriangleExampleVariables',['../structTriangleExampleVariables.html',1,'']]],
  ['triangles',['triangles',['../structGPUTriangleList.html#a82e236c3dae30c59dfedd12105bd71a9',1,'GPUTriangleList']]],
  ['types',['types',['../structGPUPrimitive.html#abf05f0fa2a0b01eddf768d0f8daf0fb9',1,'GPUPrimitive']]]
];
