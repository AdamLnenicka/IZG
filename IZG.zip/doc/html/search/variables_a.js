var searchData=
[
  ['noftriangles',['nofTriangles',['../structGPUTriangleList.html#a8bab6c6758e097060186e69fa1560494',1,'GPUTriangleList']]],
  ['nofusedvertices',['nofUsedVertices',['../structGPUPrimitive.html#aaeea5342673689813c4aff110677d403',1,'GPUPrimitive']]],
  ['normal',['normal',['../structBunnyVertex.html#aa7f67904a835c896f368dd2e37cc46db',1,'BunnyVertex']]]
];
