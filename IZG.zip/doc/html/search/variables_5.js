var searchData=
[
  ['gl_5fposition',['gl_Position',['../structGPUVertexShaderOutput.html#a9ff78df1457c9f433df05ba8858d90fe',1,'GPUVertexShaderOutput']]],
  ['gl_5fvertexid',['gl_VertexID',['../structGPUVertexShaderInput.html#a4f3129bf519e2153b77ac5bbd15ea990',1,'GPUVertexShaderInput']]],
  ['gpu',['gpu',['../structGPUVertexShaderOutput.html#a7eff72bf2de93c80688800ffcd142e34',1,'GPUVertexShaderOutput::gpu()'],['../structPhongVariables.html#a21952c475e05b5a507b05527459cfcb4',1,'PhongVariables::gpu()'],['../structTriangleExampleVariables.html#a6c5c3f82065ae9aac07f9e6f11dd03b3',1,'TriangleExampleVariables::gpu()']]]
];
