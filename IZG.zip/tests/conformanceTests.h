#pragma once


#ifdef __cplusplus
extern "C" {
#endif


void runConformanceTests(const char *groundTruth);


#ifdef __cplusplus
}
#endif
