#pragma once


#ifdef __cplusplus
extern "C" {
#endif


void runPerformanceTest();


#ifdef __cplusplus
}
#endif
